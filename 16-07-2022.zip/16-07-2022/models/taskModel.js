module.exports = (sequelize, DataTypes) => {
    const Task = sequelize.define("tasks", {
        tasks: {
            type: DataTypes.STRING
        },
        isCompleted: {
            type: DataTypes.BOOLEAN
        }
    })
    return Task
}