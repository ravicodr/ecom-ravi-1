const bcrypt = require('bcrypt')
const dbConfig = require('../config/dbconfig')
const { Sequelize, DataTypes } = require('sequelize')
const sequelize = new Sequelize(
    dbConfig.DB,
    dbConfig.USER,
    dbConfig.PASSWORD, {
        host: dbConfig.HOST,
        dialect: dbConfig.dialect,
        operationAliases: false
    }
)

sequelize.authenticate().then(() => {
        console.log('Connected to DB!')
    })
    .catch(err => {
        console.log("error : " + err)
    })
const db = {}
db.Sequelize = Sequelize //base sequelize tempalte
db.sequelize = sequelize // credentials

db.employee = require('./employeeModel')(sequelize, DataTypes)
db.tasks = require('./taskModel')(sequelize, DataTypes)
db.users = require('./userModel')(sequelize, DataTypes)

db.sequelize.sync({ force: false }).then(() => {
    console.log("Database sync done!")
})

// one -> many relationship
db.employee.hasMany(db.tasks, {
    foreignKey: 'employee_id',
    as: 'task'
})
db.tasks.belongsTo(db.employee, {
    foreignKey: 'employee_id',
    as: 'employee'
})

module.exports = db