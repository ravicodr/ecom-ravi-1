const bcrypt = require('bcrypt')
module.exports = (sequelize, DataTypes) => {
    const User = sequelize.define("users", {
        username: {
            type: DataTypes.STRING,
            allowNull: false,
            unique: true
        },
        email: {
            type: DataTypes.STRING,
            allowNull: false,
            unique: true,
            validate: {
                isEmail: true
            }

        },
        password: {
            type: DataTypes.STRING,
            allowNull: false

        }
    })
    User.beforeCreate((user, options) => {
        const encryptpassword = bcrypt.hashSync(user.password, 10) //salt
        user.password = encryptpassword
    })
    return User
}