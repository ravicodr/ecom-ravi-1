const jwt = require('jsonwebtoken')
const config = require('../config/authconfig')

const isAuthentication = async(req, res, next) => {
    let token = await req.headers["x-access-token"]
    if (!token) {
        res.send('No token passed')
    }
    try {
        if (await jwt.verify(token, config.secret))
            console.log(token)
            //  res.locals.id = decoded.id

        next()
    } catch (error) {
        res.send("error : " + error)
    }
}

module.exports = {
    isAuthentication
}