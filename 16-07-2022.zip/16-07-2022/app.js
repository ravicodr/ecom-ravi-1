const express = require('express')
const app = express()

app.use(express.json())
app.use(express.urlencoded({ extended: true }))

const employeeRouter = require('./routes/employeeRoutes')
const taskRouter = require('./routes/taskRoutes')
const authRoutes = require('./routes/authRouter')

app.use('/api3', authRoutes)
app.use('/api2', taskRouter)
app.use('/api', employeeRouter)

const port = process.env.PORT || 8080

app.listen(port, () => {
    console.log(`server started at ${port}`)
})