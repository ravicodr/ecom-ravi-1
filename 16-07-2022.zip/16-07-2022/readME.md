Here:
1) Rest Api -> CRUD operations in todo app
2) User authentication 
3) table relationship ->praent to child table.


Lets break the problem down :
TodoApp
1) Employee 2) Task 3) user authentication
 one to many relationship

 Example: Employee named Karan -> ID(Primary Key) -> foreign key in our task table(empoyee_id)
 2) crud and authentication
