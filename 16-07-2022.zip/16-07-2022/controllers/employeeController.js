const db = require('../models')

const Employee = db.employee
const Task = db.tasks

//!)CRUD operations -> create,reap,update,delete
//1) CReate:
const addEmployee = async(req, res) => {
    let info = {
        name: req.body.name,
        title: req.body.title,
        status: req.body.status ? req.body.status : false
    }
    const employee = await Employee.create(info)
    res.status(200).send(employee)
    console.log(employee)
}



//2) read -> get request
const getEmployee = async(req, res) => {
    const employee = await Employee.findAll({})
    res.status(200).send(employee)
    console.log("request confirmed!")
}

const getOneEmployee = async(req, res) => {
    let id = req.params.id
    const employee = await Employee.findOne({ where: { id: id } })
    res.status(200).send(employee)
    console.log("request confirmed!")

}

const updateEmployee = async(req, res) => {
    let id = req.params.id
    const employee = await Employee.update({ where: { id: id } })
    res.status(200).send(employee)
    console.log("request confirmed!")

}

const deleteEmployee = async(req, res) => {
    let id = req.params.id
    const employee = await Employee.destroy({ where: { id: id } })
    res.status(200).send("Employee data is deleted")
    console.log("request Deleted!")

}
const getEmployeeTasks = async(req, res) => {
    const id = req.params.id
    const data = await Employee.findAll({
        include: [{
            model: Task,
            as: 'task'
        }],
        where: { id: id }
    })
    res.status(200).send(data)
}
module.exports = {
    addEmployee,
    getEmployee,
    getOneEmployee,
    updateEmployee,
    deleteEmployee,
    getEmployeeTasks
}