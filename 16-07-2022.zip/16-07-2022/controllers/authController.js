const db = require('../models')
const bcrypt = require('bcrypt')
const jwt = require('jsonwebtoken')
const config = require('../config/authconfig')
const User = db.users

const signup = async(req, res) => {
    const data = {
        username: req.body.username,
        email: req.body.email,
        password: req.body.password
    }
    try {
        const user = await User.create(data)
        res.status(200).send("Account created successfully")
        console.log(user)
    } catch (error) {
        res.status(402).send("invalid parameter: " + error)
    }

}

const signin = async(req, res) => {
    const user = await User.findOne({ where: { email: req.body.email } })
    if (!user) return res.status(404).send('User not found')
    console.log("user found")
    if (!await bcrypt.compare(req.body.password, user.password)) {
        return res.send('Invalid Password')
    }

    const accessToken = await jwt.sign({ id: user.id, email: user.email }, config.secret, { expiresIn: 86400 })
    res.status(200).send({
        id: user.id,
        username: user.username,
        accessToken: accessToken
    })
}

module.exports = {
    signup,
    signin
}