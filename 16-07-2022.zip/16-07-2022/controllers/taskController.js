const db = require('../models')

const Task = db.tasks

//!)CRUD operations -> create,reap,update,delete
//1) CReate:
const addTask = async(req, res) => {
    let info = {

        task: req.body.task,
        isCompleted: req.body.isCompleted ? req.body.isCompleted : false
    }
    const task = await Task.create(info)
    res.status(200).send("task added Successfully")
}

//2) read -> get request
const getAllTask = async(req, res) => {
    const task = await Task.findAll({})
    res.status(200).send(task)
    console.log("request confirmed!")
}



module.exports = {
    addTask,
    getAllTask
}