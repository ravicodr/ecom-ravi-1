module.exports = {
    secret: "This-is-secret-key"
}