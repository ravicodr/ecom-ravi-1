module.exports = {
    HOST: 'localhost',
    USER: 'userss',
    PASSWORD: 'pass',
    DB: 'taskapp',
    dialect: 'mysql'
}