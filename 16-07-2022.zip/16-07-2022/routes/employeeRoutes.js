const employeeController = require('../controllers/employeeController')
const router = require('express').Router()

router.post('/addEmployee', employeeController.addEmployee)
router.get('/allemployee', employeeController.getEmployee)
router.get('/:id', employeeController.getOneEmployee)
router.put('/:id', employeeController.updateEmployee)
router.delete('/:id', employeeController.deleteEmployee)
router.get('/getemployeetask/:id', employeeController.getEmployeeTasks)

module.exports = router