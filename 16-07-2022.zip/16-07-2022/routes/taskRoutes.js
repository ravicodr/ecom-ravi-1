const taskController = require('../controllers/taskController')
const router = require('express').Router()
const authValidator = require('../middleware/authValidator')

router.post('/addtask', authValidator.isAuthentication, taskController.addTask)
router.get('/alltask', taskController.getAllTask)

//homework - get the id after auth validation and send the data of that particular user ID

//res.locals.id -> next function

module.exports = router